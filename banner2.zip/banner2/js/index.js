window.onload = function(){
	var _all = $('._all'),
	 	banner_img_all = $('.banner_img_all'),
	 	len = $('.banner_img').length,
	 	banner_icon = $('.banner_icon span'),
	 	_width = $('.banner_img img').eq(0).width(),
	 	_left,
	 	timer=null,
	 	i=0;
	 	//console.log(len);
	 	//鼠标点击切换
	 	banner_icon.on('click',function(){
	 		i = banner_icon.index($(this))
	 		//console.log(i)
	 		/* _left = -_width *i;
	 		 banner_img_all.css({
	 		 	'left':_left
	 		 })*/
	 		 sport(i);
	 	})
	 	//圆点切换
	 	function sport(num){
	 		banner_icon.eq(num).addClass('icon').siblings().removeClass('icon');
	 		if (num===3) {
	 			banner_icon.eq(0).addClass('icon').siblings().removeClass('icon');
	 		}
	 	//banner切换时间
	 	banner_img_all.stop().animate({
	 			left:  -num * _width,

	 		},500,function(){
	 			if (num == len-1) {
	 				$('.banner_img_all').css('left','0px');
	 			}

	 		})
	 	
	 	}
	 	//鼠标在banner上停止
	 	_all.on('mouseenter',function(){
	 		clearInterval(timer);
	 	})
//鼠标离开banner继续
	 	_all.on('mouseleave',function(){
	 		go();
	 	})
//自动滚动
	 	function go(){
		 	timer = setInterval(function(){
		 			i++;
		 			
		 			if (i>len-1) {
		 				i=0;
		 			}
		 			
		 			sport(i);

		 		},3000)

	 	}
	 	go();
	 
}